from django.contrib import admin

# Register your models here.
from .models import*

admin.site.register(user)

admin.site.register(user2)

admin.site.register(admin_log)

admin.site.register(signup)

admin.site.register(doctors1)

admin.site.register(appoint_booking)