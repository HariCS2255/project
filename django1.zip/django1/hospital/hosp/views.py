from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import*
from django.contrib import messages
# Create your views here.

def fun1(request):
    return HttpResponse("hello world")
def fun2(request):
    return render(request,'html1.html')

def fun3(request):
    data={'name':'babo','age':'100','place':'why'}
    return render(request,'html2.html',data)

def fun4(request):
    number={'num':10}
    return render(request,'html3.html',number)

def fun5(request):
    num={'n':[1,2,3,4,5]}
    return render(request,'html4.html',num)

def fun6(request):
    return render(request, 'html6.html')

def fun7(request):
    return render(request, 'form.html')

def fun8(request):
    if request.method=="POST":
        name=request.POST['fname']
        pas=request.POST['fpw']
        data=user.objects.create(name=name,password=pas)
        data.save()
    return render(request,"html7.html")

def fun9(request):
    return render(request, 'html8.html')

def fun10(request):
    if request.method=="POST":
        name=request.POST['fname']
        pas=request.POST['fpas']
        adr=request.POST['msg']
        gende=request.POST['gend']
        data=user2.objects.create(name=name,password=pas,address=adr,gender=gende)
        data.save()
    return render(request,"html7.html")

def fun11(request):
    return render(request,"index.html")

def fun12(request):
    return render(request, "appointment.html")

def fun13(request):
    return render(request, "admlog.html")

def fun14(request):
    d = signup.objects.all()
    return render(request,'admlog2.html',{'data': d})

def admlog2(request):
    if request.method == 'POST':
        name=request.POST['name']
        psw=request.POST['pwd']
        data=admin_log.objects.filter(name=name)
        if data:
            data1 = admin_log.objects.get(name=name)
            if data1.password == psw:
                request.session['id'] = name
                return redirect(fun14)
            else:
                messages.info(request, 'invalid username or password')
                return render(request,'admlog.html')
        else:
            messages.info(request ,'invalid username or password')
            return render(request, 'admlog.html')

def fun15(request):
    return render(request, "userlog.html")

def fun16(request):
    return render(request, "signup.html")

def signup_USER(request):
    if request.method == 'POST':
        name = request.POST['name']
        phone = request.POST['phone']
        gmail = request.POST['email']
        username = request.POST['uname']
        password = request.POST['pwd']
        gender = request.POST['gender']
        data=signup.objects.create(name=name, phone=phone, gmail=gmail, username=username, password=password, gender=gender)
        data.save()
    messages.success(request, "SIGNED IN SUCCESSFULLY!")
    return redirect(fun15)


def home(request):
    if request.method == 'POST':
        mail = request.POST['email']
        pswd = request.POST['pwd']
        data = signup.objects.filter(gmail=mail)
        if data:
            data1 = signup.objects.get(gmail=mail)
            if data1.password == pswd:
                request.session['id'] = mail
                return render(request, 'home.html')
            else:
                messages.info(request, 'invalid Email or password')
                return redirect(fun15)
        else:
            messages.info(request, 'invalid Email or Password')
            return redirect(fun15)


def logout(request):
    if 'id' in request.session:
        request.session.flush()
        return redirect(fun11)

def doctor(request):
    return render(request, "doctor.html")

def doctorform(request):
    if request.method=='POST':
        doc_name=request.POST['Dname']
        doc_id=request.POST['dID']
        doc_img=request.FILES['Dimage']
        dep=request.POST['Dep']
        data=doctors1.objects.create(Dname=doc_name, Did=doc_id, Dimage=doc_img, Dep=dep)
        data.save()
        messages.info(request, 'Doctor Successfully Added')
        return render(request, 'doctor.html')
    else:
        messages.info(request, 'Something Went Wrong. Please Try Again Later')
        return render(request,'doctor.html')

def regdoctor(request):
    d=doctors1.objects.all()
    return render(request,"regdoctor.html",{'data': d})

def del_doc(request,id):
    doctors1.objects.filter(pk=id).delete()
    return redirect(regdoctor)

def book_appoint(request):
    if request.method == 'POST':
        fname=request.POST['name']
        email=request.POST['email']
        radio=request.POST['gender']
        date=request.POST['date']
        depart=request.POST['dep']
        phone=request.POST['phone']
        msg=request.POST['message']
        payment=request.POST['payment']
        data=appoint_booking.objects.create(name=fname,email=email,date=date,phone=phone,gender=radio,department=depart,message=msg,payment_id=payment)

        data.save()
        messages.info(request,'Booked Successfully!')
        return render(request,'appointment.html')

def appoin(request):
    a=appoint_booking.objects.filter(status='pending')
    return render(request,"appointmentadmin.html", {'data':a})

def del_app(request,id):
    appoint_booking.objects.filter(pk=id).delete()
    return redirect(appoin)

def accept_app(request,id):
    appoint_booking.objects.filter(pk=id).update(status='approve')
    return redirect(appoin)

def booking_details(request):
    pending_bookings=[]
    history=[]
    d = appoint_booking.objects.filter(status='pending')
    for i in d:
        if i.email == request.session['id']:
            pending_bookings.append(i)
    d1 = appoint_booking.objects.filter(status='approve')
    for j in d1:
        if j.email == request.session['id']:
            history.append(j)
    return render(request,'bookdetail.html',{'data':pending_bookings,'data1':history})


def home2(request):
    return render(request,"home.html")