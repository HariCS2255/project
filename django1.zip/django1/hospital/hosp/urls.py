"""
URL configuration for hospital project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from.import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('1',views.fun1),
    path('2',views.fun2),
    path('3',views.fun3),
    path('4',views.fun4),
    path('5',views.fun5),
    path('6',views.fun6),
    path('7',views.fun7),
    path('8',views.fun8),
    path('9',views.fun9),
    path('10',views.fun10),
    path('11',views.fun11),
    path('12',views.fun12),
    path('13',views.fun13),
    path('14',views.fun14),
    path('15',views.admlog2),
    path('16',views.fun15),
    path('17',views.fun16),
    path('18',views.signup_USER),
    path('19',views.home),
    path('20',views.logout),
    path('21',views.doctor),
    path('22',views.doctorform),
    path('23',views.regdoctor),
    path('24/<id>',views.del_doc),
    path('25',views.book_appoint),
    path('26',views.appoin),
    path('27/<id>',views.del_app),
    path('28/<id>',views.accept_app),
    path('29',views.booking_details),
    path('30',views.home2),
]
