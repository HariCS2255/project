from django.db import models

# Create your models here.
class user(models.Model):
    name=models.CharField(max_length=25)
    password=models.CharField(max_length=25)
    def __str__(self):
        return self.name

class user2(models.Model):
    name=models.CharField(max_length=25)
    password=models.CharField(max_length=25)
    address=models.CharField(max_length=50)
    radio_choices=[('Male','MALE'),('Female','FEMALE')]
    gender=models.CharField(max_length=20,choices=radio_choices,default='not_selected')
    def __str__(self):
        return self.name

class admin_log(models.Model):
    name=models.CharField(max_length=25)
    password=models.CharField(max_length=25)
    def __str__(self):
        return self.name

class signup(models.Model):
    name=models.CharField(max_length=25)
    phone=models.IntegerField()
    gmail=models.CharField(max_length=25)
    username=models.CharField(max_length=25)
    password=models.CharField(max_length=25)
    RADIO_CHOICES = [
        ('male', 'MALE'),
        ('female', 'FEMALE'),
        ('Not_specified', 'NOT_SPECIFIED')
    ]
    gender = models.CharField(max_length=20, choices=RADIO_CHOICES, default='Not_specifed')
    def __str__(self):
        return self.name

class doctors1(models.Model):
    Dname=models.CharField(max_length=25)
    Did =models.IntegerField()
    Dimage=models.FileField()
    Dep=models.CharField(max_length=25)
    def __str__(self):
        return self.Dname

class appoint_booking(models.Model):
    name=models.CharField(max_length=25)
    email=models.CharField(max_length=25)
    date=models.CharField(max_length=25)
    phone=models.IntegerField()
    department=models.CharField(max_length=25)
    message=models.CharField(max_length=25)
    payment_id=models.CharField(max_length=25)
    RADIO_CHOICES=[
        ('male','MALE'),
        ('female','FEMALE'),
        ('Not_specified','NOT_SPECIFIED')
    ]
    gender=models.CharField(max_length=20, choices=RADIO_CHOICES, default='Not_specified')
    status_choices = [
        ('approve','approve'),
        ('reject','reject'),
        ('pending','pending')
    ]
    status=models.CharField(max_length=20, choices=status_choices, default='pending')
    def __str__(self):
        return self.name

